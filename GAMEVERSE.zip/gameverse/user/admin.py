from django.contrib import admin
from .models import Profile, CompRank

# Register your models here.
admin.site.register(Profile)
admin.site.register(CompRank)